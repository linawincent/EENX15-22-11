%% spline_3d
clear
clc
robot=importrobot('simulink.urdf');
axes=show(robot);
axes.CameraPositionMode='auto';
hold all
cpts = [0.085 0.125 0.15 0 0 -0.15 -0.125 -0.09 0.085;-0.355 -0.355 -0.295 -0.295 -0.27 -0.27 -0.355 -0.355 -0.355];
cpts1=cpts*0.5+[0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425;-0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775];% smaller bezier
y=zeros(1,9);
y_q=zeros(1,51);
tpts = [0 5];
tvec = 0:0.1:5;
[q, qd, qdd, pp] = bsplinepolytraj(cpts,tpts,tvec);
[q1, qd1, qdd1, pp1] = bsplinepolytraj(cpts1,tpts,tvec);
plot3(cpts(1,:),y,cpts(2,:),'xb-')
hold all
plot3(q(1,:),y_q,q(2,:))
plot3(q1(1,:),y_q,q1(2,:))
%% simulink_2d
cpts = [0.085 0.125 0.15 0 0 -0.15 -0.125 -0.09 0.085;-0.355 -0.355 -0.295 -0.295 -0.27 -0.27 -0.355 -0.355 -0.355];
cpts1=cpts*0.5+[0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425;-0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775]; % a smaller bezier
tpts = [0 8];
tvec = 0:0.08:8;
[q, qd, qdd, pp] = bsplinepolytraj(cpts,tpts,tvec);
[q1, qd1, qdd1, pp1] = bsplinepolytraj(cpts1,tpts,tvec);
figure(1)
plot(cpts(1,:),cpts(2,:),'xb-')
hold all
plot(q(1,:), q(2,:))
plot(cpts1(1,:),cpts1(2,:),'xr-')
plot(q1(1,:),q1(2,:),'r')
xlabel('X')
ylabel('Y')
hold off

figure(2)
plot(tvec,q1)
hold all
plot([0:length(cpts1)-1],cpts1,'x')
xlabel('t')
ylabel('Position Value')
legend('X-positions','Y-positions')
hold off
%% invers kinematic och spline
clc;
clear;
cpts = [0.085 0.125 0.15 0 0 -0.15 -0.125 -0.09 0.085;-0.355 -0.355 -0.295 -0.295 -0.27 -0.27 -0.355 -0.355 -0.355];
cpts1=cpts*0.5+[0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425;-0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775];% smaller bezier kurve
tpts = [0 1];
tvec = 0:0.01:1;
[q, qd, qdd, pp] = bsplinepolytraj(cpts,tpts,tvec);
[q1, qd1, qdd1, pp1] = bsplinepolytraj(cpts1,tpts,tvec);
foot_coordinations_xy=q1;% q=higher velocity/ q1=lower velocity
theta_all=zeros(4,101);% rad(1)=theta_1'höft joint'  rad(2)=theta_2'hipp joint' rad(3)=theta_3'lår joint' rad(4)=tid

t=0;
L_1=0;
L_2=0.269;
L_3=0.253;
for i=1:1:101
z_4=foot_coordinations_xy(1,i);
y_4=foot_coordinations_xy(2,i);
x_4=0;
D=(x_4^2+y_4^2-L_1^2+z_4^2-L_2^2-L_3^2)./(2*L_2*L_3);
t_3_radianer=atan2(-sqrt(1-D^2),D);
t_3_grad=t_3_radianer*180/pi;
t_11=-atan2(-y_4,x_4)-atan2(sqrt(x_4^2+y_4^2-L_1^2),-L_1);
t_21=atan2(z_4,sqrt(x_4^2+y_4^2-L_1^2))-atan2(L_3*sin(t_3_radianer),L_2+L_3*cos(t_3_radianer));
A1=[180+180*t_11/pi;180*t_21/pi;-t_3_grad]; 
theta_all(1,i)=(180+180*t_11/pi)/180;% varv
theta_all(2,i)=(-180*t_21/pi+60)/180;%varv
theta_all(3,i)=(-t_3_grad-90)/180;%varv
theta_all(4,i)=t;
t=t+0.02;
end
xlswrite('values1_exel.xlsx',theta_all);

%% different Spline and velocity
clc;
clear;
cpts = [0.085 0.125 0.15 0 0 -0.15 -0.125 -0.09 0.085;-0.355 -0.355 -0.295 -0.295 -0.27 -0.27 -0.355 -0.355 -0.355];
A = [0.085 0.125 0.15 0 0 -0.15 -0.125 -0.09 0.085;-0.355 -0.355 -0.295 -0.295 -0.27 -0.27 -0.355 -0.355 -0.355]*0.5;
cpts1=A-[0 0 0 0 0 0 0 0 0;0.1775 0.1775 0.1775 0.1775 0.1775 0.1775 0.1775 0.1775 0.1775];
B = [0.085 0.125 0.15 0 0 -0.15 -0.125 -0.09 0.085;-0.355 -0.355 -0.295 -0.295 -0.27 -0.27 -0.355 -0.355 -0.355]*0.75;
cpts2=B-[0 0 0 0 0 0 0 0 0;0.08875 0.08875 0.08875 0.08875 0.08875 0.08875 0.08875 0.08875 0.08875];
tpts = [0 5];
tvec = 0:0.1:5;
[q, qd, qdd, pp] = bsplinepolytraj(cpts,tpts,tvec);
[q1, qd1, qdd1, pp1] = bsplinepolytraj(cpts1,tpts,tvec);
[q2, qd2, qdd2, pp2] = bsplinepolytraj(cpts2,tpts,tvec);
figure(1)
plot(-q(1,:), q(2,:),'b')
hold all
plot(-q1(1,:), q1(2,:),'y')
plot(-q2(1,:), q2(2,:))
xlabel('X')
ylabel('Y')
legend('V=0.2 m/s','V=0.1 m/s','V=0.15 m/s')
axis equal
hold off
%% invers small spline kurve simulink
clc;
clear;
cpts = [0.085 0.125 0.15 0 0 -0.15 -0.125 -0.09 0.085;-0.355 -0.355 -0.295 -0.295 -0.27 -0.27 -0.355 -0.355 -0.355];
cpts1=cpts*0.5+[0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425 0.0425;-0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775 -0.1775];% smaller bezier kurve
tpts = [0 1];
tvec = 0:0.01:1;
[q, qd, qdd, pp] = bsplinepolytraj(cpts,tpts,tvec);
[q1, qd1, qdd1, pp1] = bsplinepolytraj(cpts1,tpts,tvec);
foot_coordinations_xy=q1;% q=higher velocity/ q1=lower velocity
theta_all=zeros(4,101);% rad(1)=theta_1'hip joint'  rad(2)=theta_2'upper leg joint' rad(3)=theta_3'lower leg joint' rad(4)=time

t=0;
L_1=0;
L_2=0.269;
L_3=0.253;
for i=1:1:101
z_4=foot_coordinations_xy(1,i);
y_4=foot_coordinations_xy(2,i);
x_4=0;
D=(x_4^2+y_4^2-L_1^2+z_4^2-L_2^2-L_3^2)./(2*L_2*L_3);
t_3_radianer=atan2(-sqrt(1-D^2),D);
t_3_grad=t_3_radianer*180/pi;
t_11=-atan2(-y_4,x_4)-atan2(sqrt(x_4^2+y_4^2-L_1^2),-L_1);
t_21=atan2(z_4,sqrt(x_4^2+y_4^2-L_1^2))-atan2(L_3*sin(t_3_radianer),L_2+L_3*cos(t_3_radianer));
A1=[180+180*t_11/pi;180*t_21/pi;-t_3_grad]; 
theta_all(1,i)=(180+180*t_11/pi);% grad
theta_all(2,i)=(-180*t_21/pi);%grad
theta_all(3,i)=(-t_3_grad);%grad
theta_all(4,i)=t;
if z_4>-0.00732096 && y_4<-0.352964 % to notice when the foot is on the ground and foot on the air
    t=0;
end
t=t+0.02;
end
xlswrite('angles.xlsx',theta_all);