%% Load display robot
clear
clc
robot=importrobot('simulink.urdf');
show(robot);