clc;
clear;
L=0.495; % robot length
B=0.16; % robot weidth
L_1=0.08; % hip length
L_2=0.269; % upper leg length
L_3=0.253; % lower leg length

x_4_m=L/2; % foot x_position
z_4_m=B/2+L_1; % foot z_position
y_4_m=-0.233183; % foot y_position
T_4_m_frontright=[x_4_m;y_4_m;z_4_m]; % it is freezed and does not changes
T_4_m_backright=[-x_4_m;y_4_m;z_4_m]; % it is freezed and does not changes
T_4_m_frontleft=[x_4_m;y_4_m;-z_4_m]; % it is freezed and does not changes
T_4_m_backleft=[-x_4_m;y_4_m;-z_4_m]; % it is freezed and does not changes

% simulink inputs:
v=0;% pitch: totation around z
w=0;% roll: rotation around x
q=0; % yaw: rotation around y
x_m=0; % masscentrum x position
y_m=0; % masscentrum y position
z_m=0; % masscentrum z position


R_x=[1 0 0 0
    0 cos(w) -sin(w) 0
    0 sin(w) cos(w) 0
    0 0 0 1];
R_y=[cos(q) 0 sin(q) 0
    0 1 0 0
    -sin(q) 0 cos(q) 0
    0 0 0 1];
R_z=[cos(v) -sin(v) 0 0
    sin(v) cos(v) 0 0
    0 0 1 0
    0 0 0 1];

R_xyz=R_x*R_y*R_z; %R_xyz: Den resulterande rotationsmatris
T_m=R_xyz*[1 0 0 x_m;0 1 0 y_m;0 0 1 z_m;0 0 0 1]; % new postion of masscentrum

T_rightfront_matrix=T_m*[0 0 1 L/2;0 1 0 0;-1 0 0 B/2;0 0 0 1]; % hip right front position matrix map masscentrum
T_rightback_matrix=T_m*[0 0 1 -L/2;0 1 0 0;-1 0 0 B/2;0 0 0 1]; % hip right back position matrix map masscentrum
T_leftfront_matrix=T_m*[0 0 1 L/2;0 1 0 0;-1 0 0 -B/2;0 0 0 1]; % hip left front position matrix map masscentrum   
T_leftback_matrix=T_m*[0 0 1 -L/2;0 1 0 0;-1 0 0 -B/2;0 0 0 1]; % hip left back position matrix map masscentrum

T_rightfront_vector=[T_rightfront_matrix(1,4);T_rightfront_matrix(2,4);T_rightfront_matrix(3,4)];% hip right front position vector map masscentrum
T_rightback_vector=[T_rightback_matrix(1,4);T_rightback_matrix(2,4);T_rightback_matrix(3,4)];% hip right back position vector map masscentrum
T_leftfront_vector=[T_leftfront_matrix(1,4);T_leftfront_matrix(2,4);T_leftfront_matrix(3,4)];% hip left front position vector map masscentrum
T_leftback_vector=[T_leftback_matrix(1,4);T_leftback_matrix(2,4);T_leftback_matrix(3,4)];% hip left back position vector map masscentrum

% invers inputs:
T_rightfront_input_invers=T_4_m_frontright-T_rightfront_vector;
T_rightback_input_invers=T_4_m_backright-T_rightback_vector;
T_leftfront_input_invers=T_4_m_frontleft-T_leftfront_vector;
T_leftback_input_invers=T_4_m_backleft-T_leftback_vector;

% invers kinematics right front
x_4=T_rightfront_input_invers(1); % right front foot new x position
y_4=T_rightfront_input_invers(2); % right front foot new y position
z_4=T_rightfront_input_invers(3); % right front foot new z position

D=(x_4^2+y_4^2-L_1^2+z_4^2-L_2^2-L_3^2)/(2*L_2*L_3);
t_3=atan2(sqrt(1-D^2),D);
t_1=-atan2(-y_4,x_4)-atan2(sqrt(x_4^2+y_4^2-L_1^2),-L_1);
t_2=atan2(z_4,sqrt(x_4^2+y_4^2-L_1^2))-atan2(L_3*sin(t_3),L_2+L_3*cos(t_3));
angles_rightfront=[180+180*t_1/pi;180*t_2/pi;t_3*180/pi]; % right front angles

% invers kinematics left front
x_4=T_leftfront_input_invers(1); % left front foot new x position
y_4=T_leftfront_input_invers(2); % left front foot new y position
z_4=T_leftfront_input_invers(3); % left front foot new z position

D=(x_4^2+y_4^2-L_1^2+z_4^2-L_2^2-L_3^2)/(2*L_2*L_3);
t_3=atan2(-sqrt(1-D^2),D);
t_1=-atan2(-y_4,x_4)-atan2(sqrt(x_4^2+y_4^2-L_1^2),-L_1);
t_2=atan2(z_4,sqrt(x_4^2+y_4^2-L_1^2))-atan2(L_3*sin(t_3),L_2+L_3*cos(t_3));
angles_leftfront=[-(180+180*t_1/pi);180*t_2/pi;t_3*180/pi]; % left front angles

% invers kinematics right back
x_4=T_rightback_input_invers(1); % right back foot new x position
y_4=T_rightback_input_invers(2); % right back foot new y position
z_4=T_rightback_input_invers(3); % right back foot new z position

D=(x_4^2+y_4^2-L_1^2+z_4^2-L_2^2-L_3^2)/(2*L_2*L_3);
t_3=atan2(sqrt(1-D^2),D);
t_1=-atan2(-y_4,x_4)-atan2(sqrt(x_4^2+y_4^2-L_1^2),-L_1);
t_2=atan2(z_4,sqrt(x_4^2+y_4^2-L_1^2))-atan2(L_3*sin(t_3),L_2+L_3*cos(t_3));
angles_rightback=[-(180+180*t_1/pi);180*t_2/pi;t_3*180/pi]; % right back angles

% invers kinematics left back
x_4=T_leftback_input_invers(1); % left back foot new x position
y_4=T_leftback_input_invers(2); % left back foot new y position
z_4=T_leftback_input_invers(3); % left back foot new z position

D=(x_4^2+y_4^2-L_1^2+z_4^2-L_2^2-L_3^2)/(2*L_2*L_3);
t_3=atan2(-sqrt(1-D^2),D);
t_1=-atan2(-y_4,x_4)-atan2(sqrt(x_4^2+y_4^2-L_1^2),-L_1);
t_2=atan2(z_4,sqrt(x_4^2+y_4^2-L_1^2))-atan2(L_3*sin(t_3),L_2+L_3*cos(t_3));
angles_leftback=[(180+180*t_1/pi);180*t_2/pi;t_3*180/pi]; % left back angles
